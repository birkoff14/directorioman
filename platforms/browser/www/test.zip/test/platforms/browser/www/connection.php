<?php
$link = mysqli_connect("mysql.hostinger.es","u917808678_test","rexianos85","u917808678_test");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?> 
